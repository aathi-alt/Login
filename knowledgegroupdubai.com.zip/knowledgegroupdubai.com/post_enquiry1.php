<?php
 if(isset($_POST['submit'])){
  include("/var/www/goldenunicon.com/includes/class.phpmailer.php");
  $name         = $_POST['name'];
  $email        = $_POST['email'];
  $mobile       = $_POST['phone'];
  $city     = $_POST['city'];
  $qualification       = $_POST['qualification'];
  $education       = $_POST['education'];
  $course      = $_POST['course'];
  $captcha =$_POST['g-recaptcha-response'];
  $contact_name ="Please check the Requirement";
  $message = "";
//echo "<pre>";print_r($_POST);
  $subject_thankyou = "";
  $message_thankyou = "";
  $mail = new PHPMailer;
  $mail->IsSMTP(); // enable SMTP
  $mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
  $mail->SMTPAuth  = true;  // authentication enabled
  $mail->SMTPSecure = 'ssl';
  $mail->Host     = "email-smtp.ap-south-1.amazonaws.com";/*Specify main and backup SMTP servers*/
  $mail->Port     = 465;
  $mail->SMTPAuth = true;/*Enable SMTP authentication*/
  $mail->Username = "AKIA3JOSQMRIWC45JYSX";/*SMTP username*/
  $mail->Password = "BMczjfHKIFvlQgBkdSMO+m5j4dJEuQemnQrpCDPrrKpP";/*SMTP password*/
  $mail->setFrom('support@goldenunicon.com', 'Shiv.S | Goldenunicon');
  $mail->addAddress($email , $name);
  $mail->isHTML(true);
  $mail->Subject = $subject_thankyou;
  $mail->Body    = $message_thankyou;
  $mail->AltBody = $subject_thankyou;
  $mail->send();
  $subject ='Enquiry for Knowledgegroup Dubai'; 
  $email_header ='<html style="color: rgb(34, 34, 34); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: -webkit-auto; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); max-width: 575px; line-height: 18px; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">
                    <head>
                      <meta name="viewport" content="width=device-width" />
                      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
                  </head>
                  <body bgcolor="#FFFFFF" text="#000000"  style="color: rgb(34, 34, 34); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: -webkit-auto; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); max-width: 575px; line-height: 18px; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">
                  <table style="font-family:Helvetica,Arial,sans-serif;background:#EFEDED;padding:0 0 10px 0;" cellpadding="0" cellspacing="0" bgcolor="#EFEDED" border="0" width="100%">
                  <tbody>
                  <tr>
                  <td align="center">
                  <table width="96%" cellpadding="0" cellspacing="0"border="0">
                  <tbody>              
                  <tr>
                  <td style="border-top:5px solid #1e96d3;background:#fff;margin:0; padding:20px; border-spacing:0px;">';

  $email_footer = '</td>
                    </tr>               
                    </tbody>
                    </table>
                    </td>
                    </tr>
                    </tbody>
                    </table>
                    </td>
                    </tr>              
                    </tbody>
                    </table>
                    </body>
                    </html>';

    $body = $email_header.
        '<table width="100%" cellpadding="0" cellspacing="0">
              <tr>
              <td style="margin:0; padding:0px 0px 15px 0px; border-spacing:0px;">
              <p style="font-size:14px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: bold; line-height: 1.5em; margin: 0px; padding: 0.4em; text-align: left;">
              '.$subject.'
              </p>
              </td>
              </tr>
              <tr>
              <td style="margin:0; padding:0px 0px 15px 0px; border-spacing:0px;">
              <p style="color:#000; font-size:13px; margin:0; font-family:Arial, Helvetica,sans-serif;">
              <strong>
              '.$contact_name.',
              </strong>
              <br>
              </p>
              </td>
              </tr>                     
              <tr>
              <td style="margin:0; padding:0 0 5px 0;">
              <p style="font-size:13px; background-color: rgb(234, 234, 234); color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: bold; line-height: 1.5em; margin: 0px; padding: 0.4em; text-align: left;">
              Details:
              </p>
              </td>
              </tr>
              <tr>
              <td style="margin:0; padding:0px 0px 15px 0px; border-spacing:0px;">
              <table style="font-family:Helvetica,Arial,sans-serif; font-size:12px; font-weight:bold; margin-top:10px; width:100%">
              <tbody>
              <tr>
              <td style="width:120px; padding:4px 0;">
              Name
              </td>  
              <td style="padding-right:10px;">
              :
              </td>
              <td style="font-weight:normal;">
              '.$name.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
           Department
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$mobile.'
              </td>
              </tr>
        <tr>
              <td style="padding:4px 0;">
              Designation
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$email.'
              </td>
              </tr>
        <tr>
              <td style="padding:4px 0;">
              Company Name
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$city.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
          Mobile No
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$qualification.'
              </td>
              </tr>
<tr>
              <td style="padding:4px 0;">
           Event
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$course.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
        Email
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$education.'
              </td>
              </tr>
              </tbody>
              </table>
              </td>
              </tr>
              </table>'
              .$email_footer;
             // print_r($body);die;
    $message .= $body;
$ch = curl_init();
curl_setopt_array($ch, [
CURLOPT_URL => 'https://www.google.com/recaptcha/api/siteverify',
CURLOPT_POST => true,
CURLOPT_POSTFIELDS => [
'secret' => '6Lf1GboUAAAAAGePA-QqEg1twho_OYoMK6jhBRw7',
'response' => $captcha,
'remoteip' => $_SERVER['REMOTE_ADDR']
],
CURLOPT_RETURNTRANSFER => true
]);

$output = curl_exec($ch); 
//echo $output;die;
curl_close($ch);
$json = json_decode($output); 
$json = true;
if($json){
// if($json){
    $mail = new PHPMailer;
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
    $mail->SMTPAuth  = true;  // authentication enabled
    $mail->SMTPSecure = 'ssl';
    $mail->Host     = "email-smtp.ap-south-1.amazonaws.com";/*Specify main and backup SMTP servers*/
    $mail->Port     = 465;
    $mail->SMTPAuth = true;/*Enable SMTP authentication*/
    $mail->Username = "AKIA3JOSQMRIWC45JYSX";/*SMTP username*/
    $mail->Password = "BMczjfHKIFvlQgBkdSMO+m5j4dJEuQemnQrpCDPrrKpP";/*SMTP password*/
    $mail->setFrom("support@goldenunicon.com",'Goldenunicon');
    $mail->addAddress('leadsgu@gmail.com' , 'Knowledgegroup');
    $mail->addAddress('nedumaran@knowledgegroupco.com' , 'Knowledgegroup');
    $mail->addAddress('vmpa381@gmail.com' , 'Knowledgegroup');
    $mail->addBCC('velamuruga@knowledgegroupco.com' , 'Knowledge group');
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = $subject;
  if(!$mail->Send()) {
            ?>
                  <script type="text/javascript">
                window.alert("mail sent successfully!");
                </script>
                 <?php
          }
           else{
         ?>
              <script type="text/javascript">
              window.location.href="thanks.html"; 
              </script>
             <?php
       }
       }else{
            
            echo "Invalid captcha. Please try again";
            return;

        }
}else{
        
        echo '<h2 class="text center">User has not submitted the form</h2>';
    }
?>

